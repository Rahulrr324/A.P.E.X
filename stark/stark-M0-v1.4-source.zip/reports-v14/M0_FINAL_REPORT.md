# STARK Phase 1 — M0 Final Report (v1.4)

**Scope:** corrective M0 closure. No M1 work, no APEX runtime/intelligence features.
**Status:** M0 gate logic is now real, testable, and reproducible. G7 **fails on all
available real measurement data** (documented below) and is therefore not claimed as a
positive M0 result.

This report supersedes the stale `reports/M0_FINAL_REPORT.md` (v1.1), which falsely
claimed the historical records were destroyed. They were not; they are intact and are
inventoried in `historical_artifact_inventory.txt`.

---

## 1. What was wrong (verified, not inferred)

1. **`src/phase1/aggregate.cpp` did not compile as a program.** The file the previous
   submission relied on ended mid-gate: `run()` had no `return`, no gate printing, no
   `main()`, and the anonymous namespace was never closed. The previous "aggregate"
   evidence could not have come from this source.
2. **G7 had the reported overwrite defect.** The overall flag was reset to `true` by a
   later passing group, so an earlier failure could be erased. Grouping also keyed on
   `(experiment_id, benchmark_id)`, which both (a) treated E1 and E5 as unrelated
   despite identical configuration and (b) assumed independence from a shared
   experiment id.
3. **G4 silently skipped absent baselines** (`continue`) instead of failing, and only
   accepted `Type::Double` RAM peaks — the harness serializes a measured RAM peak as
   `UInt`, so real records would have *failed* G4.
4. **G2 did not reject duplicate-only evidence.**
5. **No test seam existed.** Gate logic lived inside `run()` in an anonymous namespace,
   so no test could call the production gates. The `reports/gate_results/*.json`
   G2/G4/G7 claims had no matching test source.
6. **Release binaries segfaulted** — root cause established in §3.

## 2. Gate fixes

Gate evaluation is extracted into a single production seam used by **both** the CLI and
the tests: [`src/phase1/gates.h`](../src/phase1/gates.h) / [`src/phase1/gates.cpp`](../src/phase1/gates.cpp)
(`evaluate_gates()` -> `vector<GateReport>`). [`src/phase1/aggregate.cpp`](../src/phase1/aggregate.cpp)
is now a thin CLI over that seam with a real `main()` that exits nonzero on any gate
failure.

- **G2** — requires E1 and E5 present, both PASSED, each with ≥10 samples, and requires
  distinct `record_id`s (duplicate-only evidence fails).
- **G4** — requires **both** E1 and E5 present and PASSED; missing/non-PASSED baselines
  **fail** (never skipped). RAM: `ram_measured` must be boolean true and
  `ram_peak_bytes` a positive finite numeric value, tolerating `Int`/`UInt`/`Double`; an
  unavailable `{value:null,reason}` object never satisfies measured RAM. GPU-enabled
  (`vram_measured=true` or hardware `cuda_available=true`) requires a positive numeric
  VRAM peak; CPU-only requires an unavailability object with a **non-empty** reason and
  a null value. Malformed types are rejected by type check, without exceptions.
- **G7** — overall result initialised PASS, then only ever **assigned false**; a later
  passing group cannot erase an earlier failure, and diagnostics accumulate. Grouping is
  by the **serialized configuration block** (so E1/E5 are the two independent repeats of
  one configuration, and independence is NOT inferred from a shared experiment id).
  Independence within a group requires distinct `record_id`s. Exact formula
  `abs(x1-x2)/max(abs(x1),abs(x2))*100`; both-zero → 0%, exactly-one-zero → 100%;
  non-finite → failure. Timing 15%, memory-bandwidth (B3/B5) 20%.

## 3. Build architecture resolution

- `stark_phase1` is now the **single** Phase-1 static library; every CLI and every test
  `target_link_libraries(... stark_phase1)` with **no duplicate compilation**.
- The speculative global `-lgcc -lgcc_eh -lstdc++` flags were **removed**.
- **The Release segfault is explained and fixed.** `gdb` backtrace showed the fault
  inside `RecordStore::append` in `libstdc++-6.dll` loaded from
  `C:\Program Files\Git\mingw64\bin` — Git's **MSVCRT** runtime. On this host Git's
  `/mingw64/bin` is PATH entry **#1** while the WinLibs **UCRT** directory is entry
  **~58**. Prepending the WinLibs bin to PATH made the identical binary **pass**
  (54 assertions, 0 failures), proving the fault was DLL resolution, not code.
  Fix: `-static-libgcc -static-libstdc++` on Phase-1 targets (via the library's
  INTERFACE link options), making the binaries runtime-self-contained. This is a
  concrete, reproduced fix — not a retained superstition. See the comment block in
  [`CMakeLists.txt`](../CMakeLists.txt).

## 4. Fresh verification (exact commands, real output)

Single toolchain, recorded in `toolchain_manifest.txt`:
WinLibs **GCC 16.1.0** (`x86_64-w64-mingw32`, UCRT/POSIX/SEH), CMake 4.4.1, Ninja 1.13.2.
The PATH default `c++` (MinGW.org GCC 6.3.0) was **not** used (it lacks `<optional>`).

```
cmake -S . -B build-v14-debug   -G Ninja -DCMAKE_BUILD_TYPE=Debug   -DCMAKE_CXX_COMPILER=<winlibs>/g++.exe
cmake --build build-v14-debug          # 103/103, BUILD_EXIT=0   -> build_debug.log
ctest --test-dir build-v14-debug --output-on-failure     # 6/6 passed -> ctest_debug.log

cmake -S . -B build-v14-release -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=<winlibs>/g++.exe
cmake --build build-v14-release        # 103/103, BUILD_EXIT=0   -> build_release.log
ctest --test-dir build-v14-release --output-on-failure   # 6/6 passed -> ctest_release.log
```

Both configurations: **6/6 CTest tests pass, exit 0**. The gate regression test
(`test_phase1_gates`) exercises the production `evaluate_gates()` with **96 assertions**
and passes in Debug and Release (`regression_test_results.log`).

### Aggregator on real directories (`aggregator_real_dirs.log`)

| directory | records | gates PASS | gates FAIL | exit |
|---|---|---|---|---|
| `build/results` (3 surviving originals) | 3 | G5,G6 | G1,G2,G3,G4,G7 | **1** |
| `build/historical-regen` (6 regenerated) | 6 | G2,G4,G5,G6 | G1,G3,G7 | **1** |
| `fixtures/v14-valid` (fresh production runs) | 11 | G1–G6 | G7 | **1** |

### Aggregator on controlled fixtures (`aggregator_controlled_fixtures.log`)

| fixture | expected | observed | exit |
|---|---|---|---|
| `fixtures/controlled-valid` | all gates pass | **all PASS** | **0** |
| `fixtures/controlled-invalid-g2` | G2 (and G4/G7) fail | G2,G4,G7 FAIL | **1** |
| `fixtures/controlled-invalid-g4` | G4 fail | G4 FAIL | **1** |
| `fixtures/controlled-invalid-g7` | G7 fail | G7 FAIL | **1** |

The aggregator exits **nonzero whenever a gate fails** (verified above).

## 5. G7 is a real negative result on the archive

The specification's 15% timing tolerance is not met by any available real data:

| source | B6 | B7 | B9 |
|---|---|---|---|
| `build/historical-regen` (E1 vs E5) | 16.13% | 18.38% | 28.18% |
| fresh production E1 vs E5 run | 28.84% | — | — |

The gate is working correctly — it is *reporting* that the tiny-model medians are not
reproducible to 15% on this host. **G7 as an M0 acceptance criterion is therefore FAIL
on the archive**, not merely unverified. It PASSES only on a controlled fixture.

## 6. Historical evidence (irreducible)

Authoritative inventory with SHA-256: `historical_artifact_inventory.txt` (96 files).

- **Surviving originals — DO NOT OVERWRITE:** `build/results/`
  `P1-E1-B6-57493.json` `fcda5ecc…`, `P1-E1-B7-57493.json` `a4f1c2d5…`,
  `P1-E1-B9-57493.json` `3f9557b1…`, `tiny_dense_2l_weights.bin` `d7210547…`.
- **Regenerated (separate, clearly distinct):** `build/historical-regen/` six JSON +
  weights copy (weights hash identical to the original).
- **Test scratch:** `build/test_records_tmp/`, `build/build/test_records_tmp/`.
- **Irreversible historical limitation:** only **3 E1 records** survive. Of the original
  ~24 records, the other ~21 — and **all** original E5/CUDA/INT8 relatives — are gone.
  They were **not** recovered and **no replacements were manufactured**. The 6
  `historical-regen` records are regenerated data and are labelled as such everywhere.

## 7. Per-gate status

| Gate | Implementation | Test coverage | Archive result | Status |
|---|---|---|---|---|
| G1 hardware profile | present | via CLI fixtures | FAIL (no PROFILE in old dirs) | **PASS** (verified on fresh PROFILE) |
| G2 CPU baselines | rewritten strict | 7 cases | PASS on `historical-regen` | **PASS** |
| G3 GPU skip branch | present | via CLI fixtures | PASS on fresh dirs | **PASS** |
| G4 measured peak memory | rewritten strict | full case list | PASS on `historical-regen` | **PASS** |
| G5 accounting | present | existing suites | PASS | **PASS** |
| G6 budget evaluator | present | existing suites | PASS | **PASS** |
| G7 reproducibility | rewritten | 18 cases | **FAIL** (16–29% variance) | **FAIL on archive**; logic VERIFIED |

## 8. Non-fabrication statement

No historical record was deleted, overwritten, or manufactured. Controlled fixture
directories are explicitly synthetic test inputs derived from real records with every
edit disclosed in each fixture's `README.txt` — they are not presented as measurements.
The only edited-for-fixture field is the E5-B6 statistics block (valid) or the specific
single field named in each invalid fixture.

## 9. Reproduction

See `source_manifest.txt` (source hashes) and `toolchain_manifest.txt`. The build/test
evidence here corresponds to source hashed in `source_manifest.txt`; the two
`test_phase1_budget.cpp` / `gates`-related edits are covered by that manifest.
