/**
 * STARK Phase 1 (M0): gate evaluation implementation (spec §G/J).
 *
 * See gates.h for the contract. This file is the single source of truth for
 * the M0 acceptance gates; the CLI and the tests both call evaluate_gates().
 */

#include "gates.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <map>
#include <set>
#include <utility>

#include "bench/BudgetLedger.h"
#include "bench/ParameterAccounting.h"
#include "common/HardwareProfiler.h"

namespace stark_p1 {
namespace {

std::string pct(double v) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%.2f%%", v);
    return buf;
}

/// Symmetric relative difference, expressed directly in percent:
///     abs(x1 - x2) / max(abs(x1), abs(x2)) * 100
/// Both zero  -> 0.0%   (identical)
/// Exactly one zero -> 100.0% (definitely out of tolerance)
/// Non-finite input -> nullopt (caller treats as failure; never a pass)
std::optional<double> symmetric_rel_diff_pct(double x, double y) {
    if (!std::isfinite(x) || !std::isfinite(y)) return std::nullopt;
    if (x == 0.0 && y == 0.0) return 0.0;
    if (x == 0.0 || y == 0.0) return 100.0;
    const double denom = std::max(std::fabs(x), std::fabs(y));
    if (denom == 0.0) return 0.0;  // unreachable (both-zero handled above)
    return std::fabs(x - y) / denom * 100.0;
}

/// Extract a numeric measurement from a JSON value, tolerating Int, UInt and
/// Double (the harness serializes a measured RAM peak as UInt). Non-numeric
/// types (including the {value:null,reason} unavailable object) return false.
bool numeric_measurement(const JsonValue& v, double& out) {
    switch (v.type()) {
        case JsonValue::Type::Int:    out = static_cast<double>(v.asInt());  return true;
        case JsonValue::Type::UInt:   out = static_cast<double>(v.asUInt()); return true;
        case JsonValue::Type::Double: out = v.asDouble();                    return true;
        default:                      return false;
    }
}

/// True only for a JSON boolean whose value is true.
bool is_true_bool(const JsonValue& v) {
    return v.type() == JsonValue::Type::Bool && v.asBool();
}

/// A non-empty JSON string.
bool is_nonempty_string(const JsonValue& v) {
    return v.type() == JsonValue::Type::String && !v.asString().empty();
}

/// Hardware snapshot boolean (cuda_available) when the record carries one.
bool hardware_cuda_available(const ExperimentRecord& r) {
    if (!r.hardware.isObject()) return false;
    if (!r.hardware.has("cuda_available")) return false;
    return is_true_bool(r.hardware.get("cuda_available"));
}

/// Benchmark id from the record configuration ("" when absent).
std::string benchmark_id_of(const ExperimentRecord& r) {
    if (!r.configuration.isObject()) return {};
    if (!r.configuration.has("benchmark_id")) return {};
    const JsonValue& b = r.configuration.get("benchmark_id");
    if (b.type() != JsonValue::Type::String) return {};
    return b.asString();
}

/// Build the "latest record per experiment_id" view (by created_utc, tie broken
/// by record_id for determinism).
std::map<std::string, ExperimentRecord> latest_by_experiment(
    const std::vector<ExperimentRecord>& records) {
    std::map<std::string, ExperimentRecord> latest;
    for (const auto& r : records) {
        auto it = latest.find(r.experiment_id);
        if (it == latest.end()) {
            latest[r.experiment_id] = r;
        } else if (r.created_utc > it->second.created_utc ||
                   (r.created_utc == it->second.created_utc &&
                    r.record_id > it->second.record_id)) {
            latest[r.experiment_id] = r;
        }
    }
    return latest;
}

// ---------------------------------------------------------------------------
// G4 helper: validate the measured peak-memory block of one baseline record.
// Returns true when the block satisfies the strict measured-memory contract.
// ---------------------------------------------------------------------------
bool check_peak_memory(const ExperimentRecord& r, const std::string& id, std::string& err) {
    if (!r.peak_memory.isObject()) {
        err = id + ": peak_memory block missing or not an object";
        return false;
    }
    const JsonValue& pm = r.peak_memory;

    // --- RAM: must be a boolean true with a positive finite numeric peak ---
    if (!pm.has("ram_measured") || !pm.has("ram_peak_bytes")) {
        err = id + ": peak_memory missing ram_measured or ram_peak_bytes";
        return false;
    }
    const JsonValue& ram_m = pm.get("ram_measured");
    const JsonValue& ram_p = pm.get("ram_peak_bytes");
    if (ram_m.type() != JsonValue::Type::Bool) {
        err = id + ": ram_measured is not a boolean";
        return false;
    }
    if (!ram_m.asBool()) {
        err = id + ": ram_measured is false (RAM peak was not measured)";
        return false;
    }
    double ram_val = 0.0;
    if (!numeric_measurement(ram_p, ram_val)) {
        // Includes the {value:null,reason} unavailable object: an unavailable
        // RAM object can never satisfy a measured-RAM requirement.
        err = id + ": ram_measured=true but ram_peak_bytes is not a numeric measurement";
        return false;
    }
    if (!std::isfinite(ram_val) || ram_val <= 0.0) {
        err = id + ": ram_peak_bytes measured value is not positive/finite";
        return false;
    }

    // --- VRAM: GPU-enabled workloads need a measured numeric value; CPU-only
    //     workloads must document unavailability with a non-empty reason. ---
    if (!pm.has("vram_measured")) {
        err = id + ": peak_memory missing vram_measured";
        return false;
    }
    const JsonValue& vram_m = pm.get("vram_measured");
    if (vram_m.type() != JsonValue::Type::Bool) {
        err = id + ": vram_measured is not a boolean";
        return false;
    }
    const bool vram_measured = vram_m.asBool();
    const bool gpu_workload = vram_measured || hardware_cuda_available(r);

    if (gpu_workload) {
        if (!vram_measured) {
            err = id + ": GPU-capable hardware but vram_measured is false";
            return false;
        }
        if (!pm.has("vram_peak_bytes")) {
            err = id + ": GPU-enabled but vram_peak_bytes missing";
            return false;
        }
        double vram_val = 0.0;
        if (!numeric_measurement(pm.get("vram_peak_bytes"), vram_val)) {
            err = id + ": GPU-enabled but vram_peak_bytes is not a numeric measurement";
            return false;
        }
        if (!std::isfinite(vram_val) || vram_val <= 0.0) {
            err = id + ": GPU-enabled but vram_peak_bytes is not positive/finite";
            return false;
        }
    } else {
        // CPU-only: VRAM must be an object documenting unavailability with a
        // non-empty reason. Malformed/missing reasons fail.
        if (!pm.has("vram_peak_bytes")) {
            err = id + ": CPU-only but vram_peak_bytes missing (no unavailability reason)";
            return false;
        }
        const JsonValue& vram_p = pm.get("vram_peak_bytes");
        if (!vram_p.isObject()) {
            err = id + ": CPU-only but vram_peak_bytes is not an unavailability object";
            return false;
        }
        if (!vram_p.has("reason") || !is_nonempty_string(vram_p.get("reason"))) {
            err = id + ": CPU-only vram unavailability has no non-empty reason";
            return false;
        }
        if (!vram_p.has("value") || !vram_p.get("value").isNull()) {
            err = id + ": CPU-only vram unavailability must carry a null value";
            return false;
        }
    }
    return true;
}

}  // namespace

std::vector<GateReport> evaluate_gates(const std::vector<ExperimentRecord>& records) {
    std::vector<GateReport> gates;
    const auto latest = latest_by_experiment(records);

    // ---- G1: hardware profile collected, provenance for nulls ----
    {
        GateReport g;
        g.gate = "G1 hardware profile collected";
        auto it = latest.find("PROFILE");
        if (it == latest.end()) {
            g.detail = "no PROFILE record found (run profiler_cli)";
        } else {
            const ExperimentRecord& hw_rec = it->second;
            bool pass = hw_rec.status == RunStatus::PASSED && !hw_rec.hardware.isNull();
            std::string detail;
            if (pass) {
                StaticHardwareProfile hw = StaticHardwareProfile::from_json(hw_rec.hardware);
                auto errs = hw.validate();
                pass = errs.empty();
                detail = errs.empty()
                             ? "cpu=" + hw.cpu_model +
                                   ", ram_total=" + std::to_string(hw.ram_total_bytes.value_or(0))
                             : errs[0];
            } else {
                detail = hw_rec.status_reason;
            }
            g.pass = pass;
            g.detail = detail;
        }
        gates.push_back(g);
    }

    // ---- G2: CPU baselines present and complete (both E1 and E5, >=10 samples) ----
    {
        GateReport g;
        g.gate = "G2 CPU baselines present and complete";
        bool pass = false;
        std::string detail;

        auto e1_it = latest.find("E1");
        auto e5_it = latest.find("E5");
        const bool e1_present = e1_it != latest.end();
        const bool e5_present = e5_it != latest.end();
        const bool e1_ok = e1_present && e1_it->second.status == RunStatus::PASSED;
        const bool e5_ok = e5_present && e5_it->second.status == RunStatus::PASSED;

        if (!e1_present) {
            detail = "E1 baseline record missing (run run_baseline --baseline E1)";
        } else if (!e5_present) {
            detail = "E5 baseline record missing (required independent repeat)";
        } else if (!e1_ok) {
            detail = "E1 baseline not PASSED";
        } else if (!e5_ok) {
            detail = "E5 baseline not PASSED";
        } else if (e1_it->second.record_id == e5_it->second.record_id) {
            detail = "E1 and E5 resolve to the same record_id (duplicate-only evidence)";
        } else {
            const ExperimentRecord& e1 = e1_it->second;
            const ExperimentRecord& e5 = e5_it->second;
            const size_t n1 = e1.statistics.has_value() ? e1.statistics->samples.size() : 0;
            const size_t n5 = e5.statistics.has_value() ? e5.statistics->samples.size() : 0;
            if (n1 < 10) {
                detail = "E1 baseline has <10 samples (has " + std::to_string(n1) + ")";
            } else if (n5 < 10) {
                detail = "E5 baseline has <10 samples (has " + std::to_string(n5) + ")";
            } else {
                pass = true;
                detail = "E1 and E5 present, distinct, each with >=10 samples";
            }
        }
        g.pass = pass;
        g.detail = detail;
        gates.push_back(g);
    }

    // ---- G3: GPU branch — records exist and complete OR explicitly skipped ----
    {
        GateReport g;
        g.gate = "G3 GPU branch complete-or-skipped with reason";
        bool cuda = HardwareProfiler::cudaRuntimeAvailable();
        bool pass = true;
        std::string detail;
        if (cuda) {
            detail = "CUDA present: E2/B4/B5 records required PASSED";
            for (const char* id : {"E2", "B4", "B5"}) {
                auto it = latest.find(id);
                if (it == latest.end() || it->second.status != RunStatus::PASSED) {
                    pass = false;
                    detail = std::string(id) + " missing or not PASSED (CUDA available)";
                    break;
                }
            }
        } else {
            for (const char* id : {"E2", "B4", "B5"}) {
                auto it = latest.find(id);
                if (it == latest.end()) {
                    detail = std::string(id) + " record missing entirely (must record skipped status)";
                    pass = false;
                    break;
                }
                const auto& r = it->second;
                if (r.status != RunStatus::SKIPPED && r.status != RunStatus::NOT_ATTEMPTED) {
                    detail = std::string(id) + " present but not marked skipped (no CUDA available)";
                    pass = false;
                    break;
                }
                if (r.status_reason.empty()) {
                    detail = std::string(id) + " skipped without reason";
                    pass = false;
                    break;
                }
                detail = std::string(id) + ": SKIPPED — " + r.status_reason;
            }
            if (pass && detail.empty()) detail = "no CUDA; skip records required";
        }
        g.pass = pass;
        g.detail = detail;
        gates.push_back(g);
    }

    // ---- G4: strict baseline + measured peak memory ----
    {
        GateReport g;
        g.gate = "G4 peak memory measured";
        bool pass = true;
        std::string detail;
        std::vector<std::string> checked;

        for (const char* id : {"E1", "E5"}) {
            auto it = latest.find(id);
            if (it == latest.end()) {
                pass = false;
                detail = std::string(id) + ": baseline record missing (G4 requires both E1 and E5)";
                continue;
            }
            const ExperimentRecord& r = it->second;
            if (r.status != RunStatus::PASSED) {
                pass = false;
                detail = std::string(id) + ": baseline not PASSED (G4 requires a measured baseline)";
                continue;
            }
            std::string err;
            if (!check_peak_memory(r, id, err)) {
                pass = false;
                detail = err;
                continue;
            }
            checked.push_back(id);
        }

        if (pass && checked.size() == 2) {
            detail = "E1 and E5 present, PASSED, RAM peak measured; VRAM source documented per schema";
        }
        g.pass = pass;
        g.detail = detail;
        gates.push_back(g);
    }

    // ---- G5: accounting consistency ----
    {
        GateReport g;
        g.gate = "G5 parameter accounting consistent";
        bool pass = true;
        bool any = false;
        std::string detail;
        for (const auto& r : records) {
            if (r.accounting.isNull() || !r.accounting.isObject()) continue;
            any = true;
            ParameterAccounting acct = ParameterAccounting::from_json(r.accounting);
            const auto errs = acct.checkConsistency();
            if (!errs.empty()) {
                pass = false;
                detail = std::string(r.experiment_id) + ": " + errs[0];
                break;
            }
        }
        if (!any) {
            pass = false;
            detail = "no accounting records found";
        } else if (pass) {
            detail = "all accounting records pass G5 checks";
        }
        g.pass = pass;
        g.detail = detail;
        gates.push_back(g);
    }

    // ---- G6: BudgetLedger rejects over-budget (synthetic self-test) ----
    {
        GateReport g;
        g.gate = "G6 budget evaluator rejects over-budget demands";
        BudgetLedger ledger;
        ledger.vram_budget_bytes = 1000;
        ledger.ram_budget_bytes = 10000;
        ledger.storage_budget_bytes = 100000;
        ledger.safety_headroom_frac = 0.10;
        ResourceDemand d;
        d.peak_vram_bytes = 901;      // 90% of 1000 > 900 effective -> VIOLATION
        d.peak_ram_bytes = 5000;      // within
        d.storage_bytes = 50000;      // within
        d.cpu_compute_seconds = 999.0;  // informational only
        auto ev = evaluate(d, ledger);
        bool pass = !ev.within_budget;
        std::string detail;
        if (pass) {
            bool vram_hit = false, no_flip_from_compute = true;
            for (const auto& v : ev.violations) {
                if (v.field == "peak_vram_bytes" && v.severity == ViolationSeverity::ENFORCED)
                    vram_hit = true;
                if (v.field == "cpu_compute_seconds" && v.severity != ViolationSeverity::INFORMATIONAL)
                    no_flip_from_compute = false;
            }
            pass = vram_hit && no_flip_from_compute;
            detail = "VRAM-only violation detected; compute fields informational";
        } else {
            detail = "over-budget demand accepted (BUG)";
        }
        auto ev2 = evaluate(d, ledger);
        if (pass && ev2.within_budget != ev.within_budget) {
            pass = false;
            detail = "evaluate() not deterministic across identical calls";
        }
        g.pass = pass;
        g.detail = detail;
        gates.push_back(g);
    }

    // ---- G7: same-config median reproducibility across independent repeats ----
    //
    // Grouping is by CONFIGURATION (the serialized configuration block), not by
    // experiment id: E1 and E5 are independent executions of the same
    // configuration, and two records that merely share an experiment id are not
    // assumed independent. Independence within a group is established by
    // distinct record_id (an exact duplicate is the same execution, not a
    // repeat).
    //
    // The overall result starts FAIL. It is only ever assigned false inside the
    // loop; a later passing group can never overwrite an earlier failure.
    {
        GateReport g;
        g.gate = "G7 same-config medians reproducible across repeats";
        bool overall_pass = true;
        std::string detail;
        bool any_group = false;

        struct RunSample {
            std::string record_id;
            double median = 0.0;
        };
        std::map<std::string, std::vector<RunSample>> groups;  // config key -> runs
        std::map<std::string, std::string> group_bench;        // config key -> benchmark id

        for (const auto& r : records) {
            if (r.status != RunStatus::PASSED || !r.statistics.has_value()) continue;
            const std::string bench = benchmark_id_of(r);
            if (bench.empty()) continue;  // baselines without a benchmark id
            const std::string key = r.configuration.dump();
            groups[key].push_back(RunSample{r.record_id, r.statistics->median});
            group_bench[key] = bench;
        }

        for (auto& [key, runs] : groups) {
            any_group = true;
            // Deduplicate by record_id: two records sharing a record_id are the
            // same execution and do not constitute an independent repeat.
            std::vector<RunSample> unique;
            std::set<std::string> seen;
            for (const auto& rs : runs) {
                if (seen.insert(rs.record_id).second) unique.push_back(rs);
            }
            const std::string bench = group_bench[key];
            if (unique.size() < 2) {
                overall_pass = false;
                detail += "missing independent repeat for " + bench +
                          " (only " + std::to_string(unique.size()) +
                          " distinct execution(s)); insufficient evidence\n";
                continue;
            }
            const bool bandwidth = (bench == "B3" || bench == "B5");
            const double allowed = bandwidth ? 20.0 : 15.0;
            for (size_t i = 1; i < unique.size(); ++i) {
                auto d = symmetric_rel_diff_pct(unique[i - 1].median, unique[i].median);
                if (!d.has_value()) {
                    overall_pass = false;
                    detail += "non-finite median in repeat pair for " + bench +
                              " (runs " + std::to_string(i) + " vs " + std::to_string(i + 1) +
                              ")\n";
                    continue;
                }
                if (*d > allowed) {
                    overall_pass = false;
                    detail += bench + " median differs " + pct(*d) + " (allowed " + pct(allowed) +
                              ") between runs " + std::to_string(i) + " and " +
                              std::to_string(i + 1) + "\n";
                }
            }
        }

        if (!any_group) {
            overall_pass = false;
            detail = "no same-configuration benchmark groups found "
                     "(G7 requires an independent repeat; single runs do not qualify)";
        } else if (overall_pass) {
            detail = "all same-configuration groups with >=2 independent repeats agree "
                     "within tolerance (timing 15% / bandwidth 20%)";
        }
        g.pass = overall_pass;
        g.detail = detail;
        gates.push_back(g);
    }

    return gates;
}

bool all_gates_pass(const std::vector<GateReport>& gates) {
    for (const auto& g : gates)
        if (!g.pass) return false;
    return true;
}

}  // namespace stark_p1
