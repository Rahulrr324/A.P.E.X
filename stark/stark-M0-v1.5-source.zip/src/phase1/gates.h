#pragma once

/**
 * STARK Phase 1 (M0): gate evaluation seam (spec §G/J)
 *
 * This header is the SINGLE production implementation of the M0 acceptance
 * gates G1..G7. It exists so that both the `aggregate` CLI and the automated
 * regression tests evaluate the EXACT same code path — the tests never
 * reimplement gate logic.
 *
 * Input: records that have already been parsed and passed
 *        ExperimentRecord::validate() (the aggregator performs that filtering;
 *        gate evaluation itself makes no schema-level judgments beyond the
 *        gate contracts).
 *
 * Output: one GateReport per gate, in a stable order (G1..G7).
 *
 * Gate semantics (rev 1.4 corrections):
 *   G2  requires BOTH E1 and E5 present AND PASSED, each with >= 10 samples,
 *       and requires them to be distinct records (duplicate-only evidence fails).
 *   G4  requires BOTH E1 and E5 present AND PASSED and validates the measured
 *       peak-memory block strictly. A missing/non-PASSED baseline FAILS G4
 *       (it is never silently skipped).
 *   G7  evaluates every same-configuration benchmark group. The overall result
 *       is initialized FAIL and can only be turned false — never back to true —
 *       so a later passing group can never erase an earlier failure.
 */

#include <string>
#include <vector>

#include "common/ExperimentRecord.h"

namespace stark_p1 {

struct GateReport {
    std::string gate;
    bool pass = false;
    std::string detail;
};

/// Evaluate gates G1..G7 over the supplied records. Deterministic.
/// Does not query live machine state except for the documented CUDA probe in G3.
std::vector<GateReport> evaluate_gates(const std::vector<ExperimentRecord>& records);

/// True when every gate in the report passes.
bool all_gates_pass(const std::vector<GateReport>& gates);

} // namespace stark_p1
