#include "bench/BenchmarkHarness.h"

#include <algorithm>
#include <chrono>
#include <stdexcept>

#ifdef _WIN32
#include <windows.h>
#include <psapi.h>
#else
#include <sys/resource.h>
#endif

#if defined(STARK_ENABLE_CUDA)
#include <cuda_runtime.h>
#define STARK_P1_CUDA_COMPILED 1
#endif

namespace stark_p1 {

using Clock = std::chrono::steady_clock;

std::vector<std::string> BenchConfig::validate() const {
    std::vector<std::string> errs;
    if (benchmark_id.empty()) errs.push_back("benchmark_id empty");
    if (warmup_count < 3) errs.push_back("warmup_count must be >= 3 (spec §B)");
    if (measurement_count < 10) errs.push_back("measurement_count must be >= 10 (spec §B)");
    return errs;
}

PeakMemorySample sample_peak_memory() {
    PeakMemorySample s;
#ifdef _WIN32
    PROCESS_MEMORY_COUNTERS pmc{};
    pmc.cb = sizeof(pmc);
    if (GetProcessMemoryInfo(GetCurrentProcess(), &pmc, sizeof(pmc))) {
        s.ram_peak_bytes = static_cast<uint64_t>(pmc.PeakWorkingSetSize);
        s.ram_measured = true;
        s.provenance["ram_peak_bytes"] = "source: GetProcessMemoryInfo PeakWorkingSetSize (measured)";
    } else {
        s.provenance["ram_peak_bytes"] = "unavailable: GetProcessMemoryInfo failed";
    }
#ifdef STARK_P1_CUDA_COMPILED
    if (HardwareProfiler::cudaRuntimeAvailable()) {
        size_t freeb = 0, totalb = 0;
        if (cudaMemGetInfo(&freeb, &totalb) == cudaSuccess) {
            (void)freeb; (void)totalb;
            // VRAM peak tracking in Phase 1: free-VRAM delta sampled by the caller
            // around an allocation. The harness records the delta if a callback sets it.
            s.vram_measured = false;
            s.provenance["vram_peak_bytes"] = "unavailable: no CUDA allocation scope in this benchmark";
        }
    } else {
        s.provenance["vram_peak_bytes"] = "unavailable: built without CUDA";
    }
#else
    s.provenance["vram_peak_bytes"] = "unavailable: binary built without CUDA";
#endif
#else
    struct rusage ru{};
    if (getrusage(RUSAGE_SELF, &ru) == 0) {
        s.ram_peak_bytes = static_cast<uint64_t>(ru.ru_maxrss) * 1024ULL; // Linux: KB
        s.ram_measured = true;
        s.provenance["ram_peak_bytes"] = "source: getrusage ru_maxrss (measured)";
    } else {
        s.provenance["ram_peak_bytes"] = "unavailable: getrusage failed";
    }
    s.provenance["vram_peak_bytes"] = "unavailable: binary built without CUDA";
#endif
    return s;
}

BenchResult run_benchmark(const BenchConfig& config, const TimedOp& op) {
    auto cfg_errors = config.validate();
    BenchResult result;
    result.config = config;
    for (const auto& e : cfg_errors) {
        result.failures.push_back({"config", e, false});
    }
    if (!cfg_errors.empty()) {
        result.ok = false;
        result.error = "invalid configuration";
        return result;
    }

    try {
        for (uint32_t i = 0; i < config.warmup_count; ++i) op();
    } catch (const std::exception& ex) {
        result.ok = false;
        result.error = std::string("warmup failed: ") + ex.what();
        result.failures.push_back({"warmup", result.error, false});
        return result;
    }

    std::vector<double> samples;
    samples.reserve(config.measurement_count);
    for (uint32_t i = 0; i < config.measurement_count; ++i) {
        auto t0 = Clock::now();
        try {
            op();
        } catch (const std::exception& ex) {
            result.ok = false;
            result.error = std::string("iteration ") + std::to_string(i) + " failed: " + ex.what();
            result.failures.push_back({"iteration", result.error, false});
            result.stats = compute_statistics(std::move(samples));  // partial samples kept
            return result;
        }
        auto t1 = Clock::now();
        double sec = std::chrono::duration<double>(t1 - t0).count();
        if (!(sec >= 0.0)) {  // clock sanity; steady_clock should never go backwards
            result.failures.push_back({"timer", "non-monotonic sample discarded", false});
            continue;
        }
        samples.push_back(sec);
    }

    if (samples.size() < config.measurement_count && result.failures.empty()) {
        result.failures.push_back({"timer", "some samples discarded by clock sanity check", false});
    }
    result.stats = compute_statistics(std::move(samples));
    result.peak = sample_peak_memory();
    result.ok = true;
    return result;
}

JsonValue BenchResult::peak_memory_json() const {
    JsonValue o = JsonValue::object();
    auto reasoned = [&](const std::optional<uint64_t>& v, const char* key) {
        if (v.has_value()) return JsonValue::uinteger(*v);
        JsonValue r = JsonValue::object();
        r.set("value", JsonValue::null());
        auto it = peak.provenance.find(key);
        r.set("reason", JsonValue::str(it != peak.provenance.end() ? it->second : "unavailable"));
        return r;
    };
    o.set("ram_peak_bytes", reasoned(peak.ram_peak_bytes, "ram_peak_bytes"));
    o.set("vram_peak_bytes", reasoned(peak.vram_peak_bytes, "vram_peak_bytes"));
    o.set("ram_measured", JsonValue::boolean(peak.ram_measured));
    o.set("vram_measured", JsonValue::boolean(peak.vram_measured));
    return o;
}

ExperimentRecord make_benchmark_record(const std::string& record_id,
                                       const std::string& experiment_id,
                                       const std::string& kind,
                                       RunStatus status,
                                       const std::string& status_reason,
                                       const BenchResult& result,
                                       const JsonValue& hardware,
                                       const DeterminismInfo& determinism,
                                       const JsonValue& accounting,
                                       const JsonValue& budget,
                                       const std::map<std::string, JsonValue>& extra_provenance) {
    ExperimentRecord rec;
    rec.record_id = record_id;
    rec.schema_version = "STARKP1 1";
    rec.created_utc = RecordStore::utc_timestamp_now();
    rec.stark_phase = "P1";
    rec.kind = kind;
    rec.experiment_id = experiment_id;
    rec.status = status;
    rec.status_reason = status_reason;
    rec.hardware = hardware;
    rec.software = [] {
        // Software/toolchain identity from compile-time macros (no fabrication).
        JsonValue o = JsonValue::object();
#if defined(_MSC_VER)
        o.set("compiler", JsonValue::str(std::string("MSVC ") + std::to_string(_MSC_VER)));
#elif defined(__clang__)
        o.set("compiler", JsonValue::str(std::string("Clang ") + __clang_version__));
#elif defined(__GNUC__)
        o.set("compiler", JsonValue::str(std::string("GCC ") + std::to_string(__GNUC__) + "." +
                                         std::to_string(__GNUC_MINOR__) + "." +
                                         std::to_string(__GNUC_PATCHLEVEL__)));
#else
        o.set("compiler", JsonValue::str("unknown"));
#endif
#ifdef NDEBUG
        o.set("build_type", JsonValue::str("Release"));
#else
        o.set("build_type", JsonValue::str("Debug"));
#endif
        o.set("benchmark_libs", JsonValue::str("standard library only"));
        return o;
    }();
    rec.determinism = determinism;
    rec.accounting = accounting;
    rec.budget = budget;
    rec.failures = result.failures;
    if (status == RunStatus::PASSED) rec.statistics = result.stats;

    // configuration block
    JsonValue cfg = JsonValue::object();
    cfg.set("benchmark_id", JsonValue::str(result.config.benchmark_id));
    cfg.set("warmup_count", JsonValue::uinteger(result.config.warmup_count));
    cfg.set("measurement_count", JsonValue::uinteger(result.config.measurement_count));
    cfg.set("thread_count", JsonValue::uinteger(result.config.thread_count));
    cfg.set("batch_size", JsonValue::uinteger(result.config.batch_size));
    cfg.set("sequence_length", JsonValue::uinteger(result.config.sequence_length));
    JsonValue wp = JsonValue::object();
    for (const auto& [k, v] : result.config.workload_params) wp.set(k, JsonValue::str(v));
    cfg.set("workload_params", std::move(wp));
    rec.configuration = std::move(cfg);

    // precision block
    JsonValue prec = JsonValue::object();
    prec.set("compute_precision", JsonValue::str(result.config.precision));
    prec.set("storage_format", JsonValue::str(result.config.storage_format));
    rec.precision = std::move(prec);

    // peak memory
    rec.peak_memory = result.peak_memory_json();

    // provenance
    for (const auto& [k, v] : extra_provenance) rec.provenance[k] = v;

    return rec;
}

} // namespace stark_p1
